# Roblox Simulator Ultimate

Projeto demonstrativo em React + TypeScript + Vite. Todos os dados são fictícios e ficam no `localStorage` do navegador.

## Requisitos
- Node.js 18 ou superior
- npm

## Executar
```bash
npm install
npm run dev
```
Abra o endereço local informado pelo Vite (normalmente http://localhost:5173).

## Gerar versão de produção
```bash
npm run build
npm run preview
```

## Funcionalidades implementadas
- Interface responsiva com navegação entre Início, Descobrir, Loja, Amigos, Perfil e Configurações.
- Painel flutuante `</>` com Dashboard, saldo de Robux fictícios, nickname, username, avatar, amizades, Roblox Plus Simulator e configurações.
- Loja com compra/equipamento usando saldo fictício.
- Favoritos, jogos recentes, pesquisa e filtros.
- Lista de amigos, solicitações e perfis sugeridos.
- Persistência local via `localStorage` e restauração dos dados padrão.
- Tema escuro e descrição/status do perfil.

## Observações
- Não existe integração com a plataforma Roblox, autenticação, pagamentos ou servidores externos.
- As imagens de capa são imagens ilustrativas remotas do Unsplash; os dados e interações do simulador são locais.
- O painel secreto é apenas um recurso de interface da demonstração, não um executor de scripts.


## Usar como site e instalar como aplicativo

O projeto agora inclui suporte a PWA:
- Publique a pasta `dist` em uma hospedagem com HTTPS (por exemplo, Netlify, Vercel ou GitHub Pages).
- Abra o endereço publicado no Chrome do Android e use **Instalar app** ou **Adicionar à tela inicial**.
- No iPhone/iPad, abra no Safari, toque em **Compartilhar** e escolha **Adicionar à Tela de Início**.
- No PC, use o ícone de instalação na barra de endereço do navegador, quando disponível.

O aplicativo instalado usa a mesma versão web e pode abrir em janela própria. O cache permite abrir a estrutura já carregada sem conexão, mas imagens remotas e alguns recursos podem depender da internet.

**Importante:** a instalação exige que o site esteja publicado em HTTPS (ou rodando em `localhost`). O ZIP sozinho não vira um app Android APK; ele é um site instalável (PWA).


## Gerar APK Android automaticamente (sem Android Studio)

Este projeto inclui Capacitor e GitHub Actions para gerar um APK de teste na nuvem.

1. Entre em https://github.com e crie uma conta, se ainda não tiver.
2. Crie um repositório novo chamado `roblox-simulator-ultimate`.
3. Envie **todos os arquivos e pastas deste ZIP** para a raiz do repositório (incluindo a pasta `.github`).
4. Abra a aba **Actions** do repositório.
5. Se o GitHub pedir, habilite as Actions.
6. Aguarde o workflow **Build Android APK** terminar com um visto verde.
7. Abra a execução concluída, desça até **Artifacts** e baixe `Roblox-Simulator-APK`.
8. Extraia o ZIP baixado: dentro estará `app-debug.apk`. Esse é o APK para instalar no Android.

O workflow também roda automaticamente quando você envia alterações para a branch `main`.

Observações:
- É um APK de depuração (debug), adequado para instalar e testar; não é uma versão assinada para publicação na Play Store.
- O APK só será gerado depois que o workflow terminar com sucesso.
- O simulador é fictício e não se conecta à Roblox, não altera contas reais e não fornece Robux reais.
