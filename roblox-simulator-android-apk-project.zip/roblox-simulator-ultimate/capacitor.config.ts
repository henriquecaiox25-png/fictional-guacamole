import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.simulator.robloxultimate",
  appName: "Roblox Simulator Ultimate",
  webDir: "dist",
  bundledWebRuntime: false,
  android: {
    backgroundColor: "#101114"
  }
};

export default config;
