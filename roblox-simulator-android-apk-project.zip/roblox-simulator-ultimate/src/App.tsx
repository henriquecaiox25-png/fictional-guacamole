import { useEffect, useMemo, useState } from "react";
import {
  Home, Compass, ShoppingBag, Users, UserRound, Settings, Search, Coins,
  Code2, X, Minus, Plus, Gamepad2, Star, Heart, Play, Check, Crown,
  LayoutDashboard, UserCog, ShieldCheck, RotateCcw, Menu, Sparkles,
  CircleUserRound, Package, SlidersHorizontal, Copy, Trash2, Save,
  ChevronRight, LogOut, Bell, Zap, Shirt, CircleHelp
} from "lucide-react";

type Game = { id:number; name:string; genre:string; creator:string; players:string; rating:string; image:string; description:string };
type Friend = { id:number; username:string; nickname:string; online:boolean; playing:string; avatar:string };
type Item = { id:number; name:string; category:string; price:number; image:string; owned?:boolean };
type Page = "home"|"discover"|"shop"|"friends"|"profile"|"settings"|"game";

const games: Game[] = [
  {id:1,name:"Pet World Adventures",genre:"Simulador",creator:"Studio Pixel",players:"28,4 mil",rating:"96%",image:"https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=700",description:"Explore ilhas coloridas, colete criaturas e construa sua coleção neste mundo demonstrativo."},
  {id:2,name:"Mystery Mansion",genre:"Terror",creator:"Night Owl Games",players:"12,8 mil",rating:"94%",image:"https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=700",description:"Investigue uma mansão misteriosa e descubra seus segredos. Experiência fictícia."},
  {id:3,name:"Brookside Life",genre:"Roleplay",creator:"CloudTown",players:"41,2 mil",rating:"98%",image:"https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=700",description:"Crie sua rotina, personalize sua casa e encontre outros jogadores neste roleplay."},
  {id:4,name:"Tower Rush",genre:"Obby",creator:"Jump Labs",players:"8,1 mil",rating:"91%",image:"https://images.unsplash.com/photo-1511512578047-dfb367046420?w=700",description:"Supere obstáculos e chegue ao topo da torre."},
  {id:5,name:"Anime Clash Arena",genre:"PvP",creator:"Koi Interactive",players:"19,7 mil",rating:"97%",image:"https://images.unsplash.com/photo-1578632767115-351597cf2477?w=700",description:"Arena de combate inspirada em mundos de fantasia, com personagens originais."},
  {id:6,name:"Blocky Tycoon",genre:"Simulador",creator:"BuildBetter",players:"6,3 mil",rating:"93%",image:"https://images.unsplash.com/photo-1580234811497-9df7fd2f357e?w=700",description:"Construa seu império bloco por bloco."},
  {id:7,name:"Neon Battlegrounds",genre:"PvP",creator:"Neon Forge",players:"15,2 mil",rating:"95%",image:"https://images.unsplash.com/photo-1542751371-adc38448a05e?w=700",description:"Entre em batalhas rápidas em arenas futuristas."},
  {id:8,name:"Forest Escape",genre:"Aventura",creator:"Pine Studio",players:"4,9 mil",rating:"90%",image:"https://images.unsplash.com/photo-1448375240586-882707db888b?w=700",description:"Encontre o caminho para fora de uma floresta cheia de enigmas."}
];

const seedFriends: Friend[] = [
  {id:1,username:"BuilderNova",nickname:"Nova",online:true,playing:"Pet World Adventures",avatar:"🧑🏻‍🚀"},
  {id:2,username:"PixelMestre",nickname:"Pixel",online:true,playing:"Tower Rush",avatar:"🧑🏽‍🎨"},
  {id:3,username:"LunaDev",nickname:"Luna",online:false,playing:"Offline",avatar:"👩🏼‍💻"},
  {id:4,username:"CraftFox",nickname:"Fox",online:true,playing:"Blocky Tycoon",avatar:"🦊"},
  {id:5,username:"MisterioBR",nickname:"Misterio",online:false,playing:"Offline",avatar:"🥷"}
];

const shopItems: Item[] = [
  {id:101,name:"Cabelo Pixelado",category:"Cabelos",price:75,image:"💇"},
  {id:102,name:"Boné Neon",category:"Chapéus",price:120,image:"🧢"},
  {id:103,name:"Óculos Estelares",category:"Acessórios",price:90,image:"🕶️"},
  {id:104,name:"Moletom Urbano",category:"Roupas",price:250,image:"🧥"},
  {id:105,name:"Rosto Sorridente",category:"Cabeças e rostos",price:0,image:"😀"},
  {id:106,name:"Aura Brilhante",category:"Acessórios",price:500,image:"✨"},
  {id:107,name:"Animação de Dança",category:"Animações",price:180,image:"💃"},
  {id:108,name:"Asas Cósmicas",category:"Acessórios",price:350,image:"🪽"},
  {id:109,name:"Camiseta Básica",category:"Roupas",price:0,image:"👕"},
  {id:110,name:"Coroa Dourada",category:"Chapéus",price:750,image:"👑"}
];

const defaultState = {
  robux: 1250, nickname: "Player", username: "Player_123", bio: "Olá! Estou explorando o Roblox Simulator Ultimate.",
  plus: false, dark: false, friends: seedFriends, requests: [{id:6,username:"GameFan77",nickname:"Game Fan",online:true,playing:"Online",avatar:"🎮"}] as Friend[],
  inventory: [105,109], equipped: [105], favorites: [1,3], recent: [2,1], status: "Online"
};

function readState() {
  try {
    const raw = localStorage.getItem("rsu-data-v1");
    if (!raw) return defaultState;
    return { ...defaultState, ...JSON.parse(raw) };
  } catch { return defaultState; }
}

function Avatar({plus=false,large=false}:{plus?:boolean;large?:boolean}) {
  return <div className={`avatar ${large?"avatar-lg":""}`}>🧑🏻‍🚀{plus && <span className="avatar-crown">✦</span>}</div>;
}

function App() {
  const [data,setData] = useState<any>(readState);
  const [page,setPage] = useState<Page>("home");
  const [selectedGame,setSelectedGame] = useState<Game>(games[0]);
  const [search,setSearch] = useState("");
  const [shopCategory,setShopCategory] = useState("Todos");
  const [friendSearch,setFriendSearch] = useState("");
  const [toast,setToast] = useState("");
  const [panel,setPanel] = useState(false);
  const [panelTab,setPanelTab] = useState("Dashboard");
  const [panelMin,setPanelMin] = useState(false);
  const [mobileMenu,setMobileMenu] = useState(false);
  const [robuxInput,setRobuxInput] = useState(String(data.robux));
  const [nicknameInput,setNicknameInput] = useState(data.nickname);
  const [usernameInput,setUsernameInput] = useState(data.username);
  const [bioInput,setBioInput] = useState(data.bio);
  const [gameFilter,setGameFilter] = useState("Todos");

  useEffect(()=>{ localStorage.setItem("rsu-data-v1",JSON.stringify(data)); },[data]);
  useEffect(()=>{ if(!toast)return; const t=setTimeout(()=>setToast(""),2600); return ()=>clearTimeout(t); },[toast]);
  const notify=(s:string)=>setToast(s);
  const update=(patch:any)=>setData((d:any)=>({...d,...patch}));
  const go=(p:Page)=>{setPage(p);setMobileMenu(false);};

  const filteredGames=useMemo(()=>games.filter(g=>(gameFilter==="Todos"||g.genre===gameFilter)&&(`${g.name} ${g.genre} ${g.creator}`).toLowerCase().includes(search.toLowerCase())),[gameFilter,search]);
  const filteredFriends=useMemo(()=>[...data.friends,...data.requests].filter((f:Friend)=>`${f.username} ${f.nickname}`.toLowerCase().includes(friendSearch.toLowerCase())),[data.friends,data.requests]);

  const buy=(item:Item)=>{
    if(data.inventory.includes(item.id)){update({equipped:data.equipped.includes(item.id)?data.equipped.filter((x:number)=>x!==item.id):[...data.equipped,item.id]});notify(data.equipped.includes(item.id)?"Item desequipado.":"Item equipado!");return;}
    if(data.robux<item.price){notify("Saldo fictício insuficiente para comprar este item.");return;}
    update({robux:data.robux-item.price,inventory:[...data.inventory,item.id],equipped:[...data.equipped,item.id]});
    notify(item.price===0?"Item gratuito adicionado ao inventário!":"Compra simulada concluída!");
  };
  const toggleFavorite=(id:number)=>update({favorites:data.favorites.includes(id)?data.favorites.filter((x:number)=>x!==id):[...data.favorites,id]});
  const openGame=(g:Game)=>{setSelectedGame(g);update({recent:[g.id,...data.recent.filter((x:number)=>x!==g.id)].slice(0,5)});go("game");};
  const addFriend=(f:Friend)=>{if(data.friends.some((x:Friend)=>x.id===f.id)){notify("Este perfil já está na sua lista.");return;}update({friends:[...data.friends,f],requests:data.requests.filter((x:Friend)=>x.id!==f.id)});notify("Amizade simulada adicionada!");};
  const removeFriend=(id:number)=>{update({friends:data.friends.filter((f:Friend)=>f.id!==id)});notify("Amizade removida.");};
  const saveRobux=()=>{const n=Number(robuxInput);if(!Number.isSafeInteger(n)||n<0){notify("Digite um número inteiro válido, igual ou maior que zero.");return;}update({robux:n});notify("Saldo fictício atualizado!");};
  const saveNickname=()=>{if(!nicknameInput.trim()){notify("O nickname não pode ficar vazio.");return;}update({nickname:nicknameInput.trim()});notify("Nickname atualizado!");};
  const saveUsername=()=>{if(!/^[A-Za-z0-9_]{3,20}$/.test(usernameInput)){notify("Use 3–20 caracteres: letras, números e _.");return;}update({username:usernameInput});notify("Username atualizado!");};
  const reset=()=>{if(confirm("Restaurar todos os dados padrão? Esta ação apagará seu progresso local.")){setData(defaultState);setRobuxInput(String(defaultState.robux));setNicknameInput(defaultState.nickname);setUsernameInput(defaultState.username);notify("Simulador restaurado.");}};

  const navItems=[["home","Início",Home],["discover","Descobrir",Compass],["shop","Loja",ShoppingBag],["friends","Amigos",Users],["profile","Perfil",UserRound],["settings","Configurações",Settings]] as const;
  const gameCard=(g:Game)=><article className="game-card" key={g.id}>
    <div className="game-thumb" style={{backgroundImage:`linear-gradient(0deg,rgba(0,0,0,.28),transparent),url("${g.image}")`}} onClick={()=>openGame(g)}>
      <span className="genre-tag">{g.genre}</span><button className={`favorite ${data.favorites.includes(g.id)?"is-fav":""}`} onClick={e=>{e.stopPropagation();toggleFavorite(g.id);}} aria-label="Favoritar"><Heart size={18} fill={data.favorites.includes(g.id)?"currentColor":"none"}/></button>
    </div>
    <div className="game-info"><button className="game-name" onClick={()=>openGame(g)}>{g.name}</button><div className="muted small">{g.players} jogadores <span>·</span> {g.rating} positivo</div><button className="subtle-link" onClick={()=>openGame(g)}>Ver detalhes <ChevronRight size={14}/></button></div>
  </article>;

  return <div className={data.dark?"app dark":"app"}>
    <header className="topbar">
      <button className="mobile-menu icon-btn" onClick={()=>setMobileMenu(!mobileMenu)}><Menu/></button>
      <button className="brand" onClick={()=>go("home")}><span className="brand-mark">◩</span><span>ROBLOX</span><small>SIMULATOR</small></button>
      <div className="top-search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Pesquisar jogos, pessoas e itens"/></div>
      <div className="top-actions"><button className="robux-pill" onClick={()=>{setPanel(true);setPanelTab("Selecionar Robux");}}><span className="robux-icon">◆</span>{data.robux.toLocaleString("pt-BR")}</button><button className="profile-mini" onClick={()=>go("profile")}><Avatar plus={data.plus}/><span>{data.nickname}</span></button></div>
    </header>
    <div className="shell">
      <aside className={`sidebar ${mobileMenu?"show-mobile":""}`}>
        <div className="side-label">NAVEGAR</div>
        {navItems.map(([id,label,Icon])=><button key={id} className={`nav-item ${page===id?"active":""}`} onClick={()=>go(id as Page)}><Icon size={19}/>{label}</button>)}
        <div className="side-divider"/>
        <div className="side-label">SEU ESPAÇO</div>
        <button className="nav-item" onClick={()=>go("profile")}><Package size={19}/>Inventário</button>
        <button className="nav-item" onClick={()=>go("friends")}><Users size={19}/>Amigos online <span className="count">{data.friends.filter((f:Friend)=>f.online).length}</span></button>
        <div className="sidebar-bottom"><div className="sim-note"><ShieldCheck size={17}/><span>Ambiente 100% fictício. Nada é conectado ao Roblox real.</span></div><div className="side-version">Simulator Ultimate · v1.0</div></div>
      </aside>
      <main className="content">
        {page==="home"&&<><div className="welcome-row"><div><div className="eyebrow">SEU UNIVERSO DE JOGOS</div><h1>Olá, {data.nickname}!</h1><p className="muted">O que vamos jogar hoje?</p></div><div className="welcome-avatar"><Avatar plus={data.plus} large/></div></div>
          <section className="hero"><div className="hero-copy"><span className="hero-label"><Sparkles size={14}/> DESTAQUE DA SEMANA</span><h2>Descubra seu<br/>próximo mundo.</h2><p>Explore experiências criadas para você nesta plataforma demonstrativa.</p><button className="primary-btn" onClick={()=>go("discover")}>Explorar jogos <ChevronRight size={17}/></button></div><div className="hero-art">🎮</div></section>
          {data.recent.length>0&&<section className="section"><div className="section-heading"><div><h2>Continue de onde parou</h2><p className="muted">Seus jogos recentes</p></div><button className="text-btn" onClick={()=>go("discover")}>Ver todos <ChevronRight size={15}/></button></div><div className="game-grid">{data.recent.map((id:number)=>games.find(g=>g.id===id)).filter(Boolean).map(g=>gameCard(g!))}</div></section>}
          <section className="section"><div className="section-heading"><div><h2>Recomendados para você</h2><p className="muted">Experiências populares no simulador</p></div><button className="text-btn" onClick={()=>go("discover")}>Descobrir mais <ChevronRight size={15}/></button></div><div className="game-grid">{games.slice(0,4).map(gameCard)}</div></section>
          <section className="section"><div className="section-heading"><div><h2>Seus favoritos</h2><p className="muted">Jogos que você salvou</p></div></div>{data.favorites.length?<div className="game-grid">{games.filter(g=>data.favorites.includes(g.id)).map(gameCard)}</div>:<div className="empty-state">Você ainda não favoritou nenhum jogo.</div>}</section>
        </>}
        {page==="discover"&&<><div className="page-heading"><div><div className="eyebrow">CATÁLOGO</div><h1>Descobrir</h1><p className="muted">Encontre sua próxima experiência favorita.</p></div><div className="heading-icon"><Compass/></div></div><div className="filter-row">{["Todos","Simulador","Terror","Roleplay","Obby","PvP","Aventura"].map(x=><button className={`filter-chip ${gameFilter===x?"selected":""}`} onClick={()=>setGameFilter(x)} key={x}>{x}</button>)}</div><div className="game-grid">{filteredGames.map(gameCard)}</div>{!filteredGames.length&&<div className="empty-state">Nenhum jogo encontrado.</div>}</>}
        {page==="game"&&<><button className="back-link" onClick={()=>go("discover")}>← Voltar ao catálogo</button><div className="detail-cover" style={{backgroundImage:`linear-gradient(90deg,rgba(12,16,24,.9),rgba(12,16,24,.1)),url("${selectedGame.image}")`}}><div><span className="genre-tag">{selectedGame.genre}</span><h1>{selectedGame.name}</h1><p>Por {selectedGame.creator}</p><button className="primary-btn" disabled><Play size={16}/> Indisponível na demonstração</button></div></div><div className="detail-stats"><div><strong>{selectedGame.players}</strong><span>Jogadores ativos (fictício)</span></div><div><strong>{selectedGame.rating}</strong><span>Avaliação demonstrativa</span></div><div><strong>{selectedGame.genre}</strong><span>Categoria</span></div></div><section className="section"><h2>Sobre esta experiência</h2><p className="muted detail-description">{selectedGame.description}</p><div className="notice"><ShieldCheck size={18}/> Este jogo é apenas uma ficha demonstrativa. Nenhum jogo real será iniciado.</div></section></>}
        {page==="shop"&&<><div className="page-heading"><div><div className="eyebrow">PERSONALIZAÇÃO</div><h1>Loja de avatar</h1><p className="muted">Itens fictícios para personalizar seu personagem.</p></div><div className="heading-icon"><ShoppingBag/></div></div><div className="shop-balance"><span>Seu saldo simulado</span><strong>◆ {data.robux.toLocaleString("pt-BR")} Robux</strong><button className="text-btn" onClick={()=>{setPanel(true);setPanelTab("Selecionar Robux");}}>Alterar saldo</button></div><div className="filter-row">{["Todos","Cabeças e rostos","Cabelos","Chapéus","Roupas","Acessórios","Animações"].map(x=><button key={x} className={`filter-chip ${shopCategory===x?"selected":""}`} onClick={()=>setShopCategory(x)}>{x}</button>)}</div><div className="shop-grid">{shopItems.filter(i=>shopCategory==="Todos"||i.category===shopCategory).map(item=>{const owned=data.inventory.includes(item.id);return <article className="item-card" key={item.id}><div className="item-art">{item.image}</div><div className="item-details"><b>{item.name}</b><span className="muted small">{item.category}</span><strong>{item.price===0?"Grátis":`◆ ${item.price}`}</strong><button className={owned?"secondary-btn":"primary-btn"} onClick={()=>buy(item)}>{owned?(data.equipped.includes(item.id)?"Equipado ✓":"Equipar"):(item.price===0?"Obter":"Comprar")}</button></div></article>})}</div></>}
        {page==="friends"&&<><div className="page-heading"><div><div className="eyebrow">SOCIAL</div><h1>Amigos</h1><p className="muted">Conecte-se com perfis fictícios da comunidade.</p></div><div className="heading-icon"><Users/></div></div><div className="friend-search"><Search size={18}/><input value={friendSearch} onChange={e=>setFriendSearch(e.target.value)} placeholder="Pesquisar amigos e perfis"/></div><section className="section"><div className="section-heading"><h2>Seus amigos <span className="muted">({data.friends.length})</span></h2></div><div className="friend-list">{filteredFriends.filter((f:Friend)=>data.friends.some((x:Friend)=>x.id===f.id)).map((f:Friend)=><div className="friend-row" key={f.id}><div className="friend-avatar">{f.avatar}<i className={f.online?"online-dot":"offline-dot"}/></div><div className="friend-main"><b>{f.nickname}</b><span className="muted small">@{f.username} · {f.online?"Online":"Offline"}</span><span className="muted tiny">{f.playing}</span></div><button className="secondary-btn compact" onClick={()=>removeFriend(f.id)}>Remover</button></div>)}</div></section><section className="section"><div className="section-heading"><h2>Solicitações <span className="muted">({data.requests.length})</span></h2></div>{data.requests.length?<div className="friend-list">{data.requests.map((f:Friend)=><div className="friend-row" key={f.id}><div className="friend-avatar">{f.avatar}</div><div className="friend-main"><b>{f.nickname}</b><span className="muted small">@{f.username}</span></div><button className="primary-btn compact" onClick={()=>addFriend(f)}><Plus size={15}/> Aceitar</button></div>)}</div>:<div className="empty-state">Nenhuma solicitação no momento.</div>}</section><section className="section"><h2>Perfis sugeridos</h2><div className="friend-list">{[{id:11,username:"ObbyCreator",nickname:"Obby Creator",online:true,playing:"Criando um jogo",avatar:"🧑🏾‍🎤"},{id:12,username:"MysteryDev",nickname:"Mystery Dev",online:false,playing:"Offline",avatar:"🧑🏻‍💻"},{id:13,username:"StudioBuilder",nickname:"Studio Builder",online:true,playing:"Online",avatar:"👩🏽‍🚀"}].filter(f=>!data.friends.some((x:Friend)=>x.id===f.id)).map(f=><div className="friend-row" key={f.id}><div className="friend-avatar">{f.avatar}</div><div className="friend-main"><b>{f.nickname}</b><span className="muted small">@{f.username} · Perfil demonstrativo</span></div><button className="secondary-btn compact" onClick={()=>addFriend(f)}><Plus size={15}/> Adicionar</button></div>)}</div></section></>}
        {page==="profile"&&<><div className="profile-banner"/><div className="profile-header"><Avatar plus={data.plus} large/><div className="profile-title"><h1>{data.nickname} {data.plus&&<span className="plus-badge"><Crown size={13}/> PLUS</span>}</h1><p className="muted">@{data.username}</p></div><button className="secondary-btn edit-profile" onClick={()=>{setPanel(true);setPanelTab("Nicknames");}}>Editar perfil</button></div><div className="profile-bio">{data.bio}</div><div className="profile-stats"><div><strong>{data.friends.length}</strong><span>Amigos</span></div><div><strong>{data.favorites.length}</strong><span>Favoritos</span></div><div><strong>◆ {data.robux.toLocaleString("pt-BR")}</strong><span>Robux fictícios</span></div></div><section className="section"><div className="section-heading"><h2>Sobre</h2><button className="text-btn" onClick={()=>{setPanel(true);setPanelTab("Nicknames");}}>Editar descrição</button></div><div className="profile-about"><span>Status</span><b>{data.status}</b><span>Assinatura</span><b>{data.plus?"Roblox Plus Simulator ativa":"Sem assinatura"}</b><span>Conta</span><b>Perfil demonstrativo</b></div></section><section className="section"><div className="section-heading"><h2>Inventário</h2><button className="text-btn" onClick={()=>go("shop")}>Abrir loja</button></div><div className="inventory-row">{data.inventory.map((id:number)=>{const item=shopItems.find(i=>i.id===id);return item?<div className="inventory-item" key={id}><span>{item.image}</span><b>{item.name}</b><small>{data.equipped.includes(id)?"Equipado":"Guardado"}</small></div>:null})}</div></section><section className="section"><h2>Atividade recente</h2><div className="activity-row"><span>🎮</span><div><b>Explorou experiências</b><small className="muted">Atividade simulada · agora</small></div></div><div className="activity-row"><span>🛍️</span><div><b>Visitou a loja de avatar</b><small className="muted">Atividade simulada</small></div></div></section></>}
        {page==="settings"&&<><div className="page-heading"><div><div className="eyebrow">PREFERÊNCIAS</div><h1>Configurações</h1><p className="muted">Personalize sua experiência no simulador.</p></div><div className="heading-icon"><Settings/></div></div><div className="settings-card"><div><b>Tema escuro</b><p className="muted small">Altera a aparência desta demonstração.</p></div><button className={`toggle ${data.dark?"on":""}`} onClick={()=>update({dark:!data.dark})}><i/></button></div><div className="settings-card"><div><b>Status do perfil</b><p className="muted small">Escolha como seu perfil aparece.</p></div><select value={data.status} onChange={e=>update({status:e.target.value})}><option>Online</option><option>Ausente</option><option>Não perturbe</option><option>Offline</option></select></div><div className="settings-card"><div><b>Dados locais</b><p className="muted small">Seus dados ficam salvos somente neste navegador.</p></div><button className="secondary-btn" onClick={reset}><RotateCcw size={16}/> Restaurar padrão</button></div><div className="notice"><ShieldCheck size={18}/> Nenhuma informação é enviada a servidores externos. O simulador não acessa contas reais.</div></>}
      </main>
    </div>

    <button className="code-fab" onClick={()=>{setPanel(true);setPanelMin(false);}} title="Abrir Simulator Control Panel"><Code2 size={23}/></button>

    {panel&&<div className={`control-panel ${panelMin?"minimized":""}`}>
      <div className="panel-titlebar"><div className="panel-brand"><span className="panel-dot"/> <b>Simulator Control Panel</b><small>LOCAL SANDBOX</small></div><div className="panel-window-actions"><button onClick={()=>setPanelMin(!panelMin)} title="Minimizar"><Minus size={16}/></button><button onClick={()=>setPanel(false)} title="Fechar"><X size={17}/></button></div></div>
      {!panelMin&&<div className="panel-body"><nav className="panel-nav">{[["Dashboard",LayoutDashboard],["Selecionar Robux",Coins],["Nicknames",UserCog],["Username",UserRound],["Avatar",Shirt],["Amigos",Users],["Roblox Plus",Crown],["Configurações",SlidersHorizontal]].map(([name,Icon]:any)=><button key={name} className={panelTab===name?"chosen":""} onClick={()=>setPanelTab(name)}><Icon size={16}/>{name}</button>)}</nav><div className="panel-content">
        {panelTab==="Dashboard"&&<><div className="panel-eyebrow">VISÃO GERAL</div><h2>Olá, {data.nickname}</h2><p className="panel-muted">Controle os dados locais da sua experiência.</p><div className="dash-stats"><div><span>ROBUX FICTÍCIOS</span><b>◆ {data.robux.toLocaleString("pt-BR")}</b></div><div><span>AMIGOS</span><b>{data.friends.length}</b></div><div><span>ITENS</span><b>{data.inventory.length}</b></div><div><span>PLUS</span><b>{data.plus?"ATIVO":"INATIVO"}</b></div></div><div className="panel-callout"><ShieldCheck size={17}/> Todas as alterações existem apenas neste simulador.</div><button className="panel-action" onClick={()=>go("profile")}>Abrir meu perfil <ChevronRight size={15}/></button></>}
        {panelTab==="Selecionar Robux"&&<><div className="panel-eyebrow">ECONOMIA SIMULADA</div><h2>Selecionar Robux</h2><p className="panel-muted">Defina o saldo fictício da sua conta.</p><div className="robux-current"><span>Saldo atual</span><b>◆ {data.robux.toLocaleString("pt-BR")}</b></div><label className="panel-label">Nova quantidade</label><input className="panel-input" type="number" min="0" step="1" value={robuxInput} onChange={e=>setRobuxInput(e.target.value)}/><div className="preset-grid">{[100,1000,10000,100000,1000000,0].map(n=><button key={n} onClick={()=>setRobuxInput(String(n))}>{n.toLocaleString("pt-BR")}</button>)}</div><button className="panel-primary" onClick={saveRobux}><Check size={16}/> Aplicar saldo</button></>}
        {panelTab==="Nicknames"&&<><div className="panel-eyebrow">IDENTIDADE</div><h2>Nickname</h2><p className="panel-muted">Nome de exibição do seu perfil.</p><label className="panel-label">Novo nickname</label><input className="panel-input" maxLength={30} value={nicknameInput} onChange={e=>setNicknameInput(e.target.value)} placeholder="Digite seu nickname"/><div className="preview-card"><Avatar plus={data.plus}/><div><b>{nicknameInput||"Seu nickname"}</b><span>@{data.username}</span></div></div><button className="panel-primary" onClick={saveNickname}><Save size={16}/> Salvar nickname</button><label className="panel-label extra-label">Descrição do perfil</label><textarea className="panel-input panel-textarea" value={bioInput} onChange={e=>setBioInput(e.target.value)} maxLength={120}/><button className="panel-secondary" onClick={()=>{update({bio:bioInput});notify("Descrição atualizada!");}}>Salvar descrição</button></>}
        {panelTab==="Username"&&<><div className="panel-eyebrow">IDENTIDADE</div><h2>Username</h2><p className="panel-muted">Identificador fictício exclusivo desta simulação.</p><label className="panel-label">Novo username</label><input className="panel-input" value={usernameInput} onChange={e=>setUsernameInput(e.target.value)} maxLength={20}/><div className="validation-hint">3–20 caracteres. Permitidos: letras, números e underline (_).</div><div className="preview-username">@{usernameInput||"seu_username"}</div><button className="panel-primary" onClick={saveUsername}><Check size={16}/> Confirmar username</button></>}
        {panelTab==="Avatar"&&<><div className="panel-eyebrow">PERSONALIZAÇÃO</div><h2>Meu avatar</h2><div className="avatar-preview-large"><Avatar plus={data.plus} large/><div><b>{data.nickname}</b><span>Avatar demonstrativo</span></div></div><p className="panel-muted">Itens equipados:</p>{data.equipped.length?data.equipped.map((id:number)=>{const item=shopItems.find(i=>i.id===id);return item?<div className="equipped-line" key={id}>{item.image} {item.name}<button onClick={()=>buy(item)}>Remover</button></div>:null}):<p className="panel-muted">Nenhum item equipado.</p>}<button className="panel-secondary" onClick={()=>{setPanel(false);go("shop");}}>Abrir loja de itens</button></>}
        {panelTab==="Amigos"&&<><div className="panel-eyebrow">SOCIAL</div><h2>Gerenciar amigos</h2><p className="panel-muted">Adicione perfis fictícios sugeridos.</p>{[{id:21,username:"DevLegend",nickname:"Dev Legend",online:true,playing:"Criando experiências",avatar:"🧑🏽‍💻"},{id:22,username:"RbxExplorer",nickname:"Explorer",online:false,playing:"Offline",avatar:"🧭"},{id:23,username:"StarPlayer",nickname:"Star Player",online:true,playing:"Online",avatar:"🌟"}].filter(f=>!data.friends.some((x:Friend)=>x.id===f.id)).map(f=><div className="panel-friend" key={f.id}><span>{f.avatar}</span><div><b>{f.nickname}</b><small>@{f.username}</small></div><button onClick={()=>addFriend(f)}>Adicionar</button></div>)}<div className="panel-callout">{data.friends.length} amizades fictícias cadastradas.</div><button className="panel-secondary" onClick={()=>{setPanel(false);go("friends");}}>Ver lista completa</button></>}
        {panelTab==="Roblox Plus"&&<><div className="panel-eyebrow">ASSINATURA DEMONSTRATIVA</div><h2>Roblox Plus Simulator</h2><div className="plus-card"><div className="plus-crown"><Crown size={28}/></div><b>PLUS</b><span>Uma experiência premium fictícia.</span><ul><li>✦ Selo especial no perfil</li><li>✦ Tema exclusivo opcional</li><li>✦ Cartão visual de benefícios</li><li>✦ Animação de ativação</li></ul><button className={data.plus?"panel-secondary":"panel-primary"} onClick={()=>{update({plus:!data.plus});notify(data.plus?"Roblox Plus Simulator desativado.":"Roblox Plus Simulator ativado! ✨");}}>{data.plus?"Desativar assinatura":"Ativar gratuitamente"}</button></div><p className="panel-muted">Não há cobrança, pagamento ou benefício oficial. É apenas uma simulação local.</p></>}
        {panelTab==="Configurações"&&<><div className="panel-eyebrow">SISTEMA</div><h2>Configurações</h2><div className="panel-setting"><div><b>Tema escuro</b><small>Alternar tema da interface principal</small></div><button className={`toggle ${data.dark?"on":""}`} onClick={()=>update({dark:!data.dark})}><i/></button></div><div className="panel-setting"><div><b>Persistência local</b><small>Salvar alterações no navegador</small></div><span className="local-status"><span/> Ativa</span></div><button className="panel-danger" onClick={reset}><RotateCcw size={16}/> Restaurar dados padrão</button></>}
      </div></div>}
    </div>}
    {toast&&<div className="toast"><Check size={17}/>{toast}</div>}
    <footer className="footer-note">ROBLOX SIMULATOR ULTIMATE <span>·</span> Projeto independente e fictício. Não afiliado ao Roblox Corporation.</footer>
  </div>;
}

export default App;
